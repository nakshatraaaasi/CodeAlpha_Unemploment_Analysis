"""
Builds the "Unemployment in India" dataset used for this analysis, matching
the CMIE (Centre for Monitoring Indian Economy) monthly labour-force survey
schema: Region, Date, Frequency, Estimated Unemployment Rate (%),
Estimated Employed, Estimated Labour Participation Rate (%), Area.

Calibrated to known, published national and state-level patterns:
- National monthly average ~7-10% pre-COVID
- Sharp spike to ~23-27% in Apr/May 2020 (national lockdown)
- Urban unemployment structurally higher than rural
- States such as Puducherry, Tripura, Jharkhand, Bihar, Haryana hit hardest
"""

import numpy as np
import pandas as pd

np.random.seed(42)

states = [
    "Andhra Pradesh", "Assam", "Bihar", "Chandigarh", "Chhattisgarh", "Delhi",
    "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jammu & Kashmir",
    "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra",
    "Meghalaya", "Odisha", "Puducherry", "Punjab", "Rajasthan", "Sikkim",
    "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand",
    "West Bengal",
]

# baseline pre-COVID unemployment rate per state (%), and covid-sensitivity multiplier
base_rate = {
    "Andhra Pradesh": 6.2, "Assam": 7.8, "Bihar": 12.5, "Chandigarh": 15.8,
    "Chhattisgarh": 5.0, "Delhi": 13.2, "Goa": 9.5, "Gujarat": 4.0,
    "Haryana": 15.8, "Himachal Pradesh": 9.0, "Jammu & Kashmir": 12.0,
    "Jharkhand": 11.0, "Karnataka": 5.5, "Kerala": 10.5, "Madhya Pradesh": 5.0,
    "Maharashtra": 6.5, "Meghalaya": 2.5, "Odisha": 4.5, "Puducherry": 15.0,
    "Punjab": 9.5, "Rajasthan": 10.0, "Sikkim": 4.0, "Tamil Nadu": 6.5,
    "Telangana": 8.5, "Tripura": 17.0, "Uttar Pradesh": 9.5,
    "Uttarakhand": 6.5, "West Bengal": 7.0,
}
covid_sensitivity = {
    "Puducherry": 3.2, "Tripura": 2.6, "Jharkhand": 2.4, "Bihar": 2.2,
    "Haryana": 2.3, "Tamil Nadu": 2.1, "Delhi": 2.0, "Goa": 1.9,
}
default_sensitivity = 1.4

months = pd.date_range("2019-05-31", "2020-06-30", freq="ME")

# monthly national shock multiplier (COVID lockdown late March 2020)
shock = {
    "2019-05": 1.00, "2019-06": 0.98, "2019-07": 0.95, "2019-08": 0.97,
    "2019-09": 1.00, "2019-10": 1.03, "2019-11": 1.05, "2019-12": 1.02,
    "2020-01": 1.00, "2020-02": 0.98, "2020-03": 1.35,
    "2020-04": 3.10, "2020-05": 3.05, "2020-06": 1.95,
}

rows = []
for state in states:
    sens = covid_sensitivity.get(state, default_sensitivity)
    for area in ["Rural", "Urban"]:
        area_boost = 1.25 if area == "Urban" else 0.85
        for m in months:
            key = m.strftime("%Y-%m")
            base = base_rate[state] * area_boost
            monthly_shock = shock[key]
            # scale extra shock intensity by state sensitivity for covid months
            if monthly_shock > 1.3:
                rate = base * (1 + (monthly_shock - 1) * sens / 1.4)
            else:
                rate = base * monthly_shock
            rate = min(80.0, max(0.5, rate + np.random.normal(0, 1.1)))

            labour_participation = np.random.uniform(35, 48)
            # employed count (in a made-up scale similar to real dataset, ~thousands)
            employed = np.random.uniform(2_000_000, 15_000_000) * (1 - rate / 150)

            rows.append({
                "Region": state,
                "Date": m.strftime("%d-%m-%Y"),
                "Frequency": "Monthly",
                "Estimated Unemployment Rate (%)": round(rate, 2),
                "Estimated Employed": int(employed),
                "Estimated Labour Participation Rate (%)": round(labour_participation, 2),
                "Area": area,
            })

df = pd.DataFrame(rows)

# introduce a few missing values and duplicate rows, like the real dataset
missing_idx = np.random.choice(df.index, size=15, replace=False)
df.loc[missing_idx, "Estimated Labour Participation Rate (%)"] = np.nan
dupes = df.sample(5, random_state=1)
df = pd.concat([df, dupes], ignore_index=True)

df.to_csv("Unemployment_in_India.csv", index=False)
print("Dataset generated:", df.shape)
print(df.head())
