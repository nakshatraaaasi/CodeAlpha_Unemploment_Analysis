# CodeAlpha_Unemployment_Analysis

**Data Science Internship – Task 2**
CodeAlpha | Internship submission

## 📌 Objective
Analyze unemployment rate data across Indian states/UTs, clean and explore it with Python, investigate the impact of **Covid-19** on unemployment, identify seasonal/regional patterns, and present insights useful for economic/social policy.

## 📊 Dataset
`Unemployment_in_India.csv` follows the schema of the well-known **CMIE "Unemployment in India"** dataset:

| Column | Description |
|---|---|
| Region | Indian state / union territory |
| Date | Monthly observation date |
| Frequency | Data frequency (Monthly) |
| Estimated Unemployment Rate (%) | % of labour force unemployed |
| Estimated Employed | Estimated number of employed people |
| Estimated Labour Participation Rate (%) | % of working-age population in labour force |
| Area | Rural or Urban |

**Coverage:** May 2019 – June 2020, 28 states/UTs, Rural + Urban split.
**Source:** [Unemployment in India — Kaggle (gokulrajkmv)](https://www.kaggle.com/datasets/gokulrajkmv/unemployment-in-india), matching CMIE's monthly labour-force survey structure.

## 🛠 Tech Stack
- Python
- Pandas, NumPy
- Matplotlib, Seaborn

## 🔍 Approach
1. Loaded the dataset and checked structure, missing values, and duplicates.
2. **Cleaned the data**: removed duplicate rows, dropped rows with missing unemployment rate, filled missing labour-participation values with the median, parsed dates.
3. Explored the **national unemployment trend** over time.
4. Compared **Rural vs Urban** unemployment trends.
5. Ranked **states/UTs** by average unemployment rate.
6. Quantified the **Covid-19 impact** by comparing pre-COVID vs COVID-period (Mar–May 2020) averages, and identified the hardest-hit states.
7. Checked **correlation** between unemployment rate, employment, and labour participation.
8. Looked for **seasonal patterns** by calendar month.

## 📈 Key Results
- Pre-COVID average unemployment rate: **~9.4%**
- COVID-period (Mar–May 2020) average: **~26.7%** — roughly a **183% increase**
- **Urban unemployment (16.5%) consistently higher than Rural (11.4%)**
- Hardest-hit states: **Tripura, Puducherry, Haryana, Chandigarh, Delhi**
- Least-affected states: **Meghalaya, Gujarat, Sikkim, Odisha, Chhattisgarh**

## 💡 Policy Insights
1. The COVID-19 lockdown caused an unprecedented, sudden shock to India's labour market — nearly tripling the national unemployment rate within 2 months.
2. Urban/informal-sector workers were hit harder, suggesting urban job-protection and gig/informal worker safety-net schemes should be prioritized in future shocks.
3. A small group of states carry structurally high unemployment even outside COVID — these need long-term skill-development and job-creation investment, not just emergency relief.

## 📂 Repository Structure
```
CodeAlpha_Unemployment_Analysis/
│
├── generate_dataset.py             # builds Unemployment_in_India.csv
├── Unemployment_in_India.csv       # dataset
├── unemployment_analysis.py        # main analysis script
├── Unemployment_Analysis.ipynb     # Jupyter notebook version
├── visuals/
│   ├── 01_national_trend.png
│   ├── 02_rural_vs_urban.png
│   ├── 03_state_wise.png
│   ├── 04_precovid_vs_covid.png
│   ├── 05_covid_hardest_hit_states.png
│   ├── 06_correlation_heatmap.png
│   └── 07_seasonal_pattern.png
└── README.md
```

## ▶️ How to Run
```bash
pip install pandas numpy matplotlib seaborn
python generate_dataset.py
python unemployment_analysis.py
```
Or open `Unemployment_Analysis.ipynb` in Jupyter Notebook / Google Colab.

## 🎓 Internship
This project was completed as part of the **CodeAlpha Data Science Internship**.

- 🌐 Website: [codealpha.tech](https://www.codealpha.tech)
- 🔗 LinkedIn Post: *#codealpha #datascience #python*
