"""
CodeAlpha Data Science Internship - Task 2
Unemployment Analysis with Python

Analyzes unemployment rate data across Indian states/UTs, cleans the data,
explores trends, and investigates the impact of Covid-19 on unemployment.
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_style("whitegrid")
plt.rcParams["figure.autolayout"] = True

RATE_COL = "Estimated Unemployment Rate (%)"
EMP_COL = "Estimated Employed"
LPR_COL = "Estimated Labour Participation Rate (%)"

# ---------------------------------------------------------
# 1. Load the dataset
# ---------------------------------------------------------
df = pd.read_csv("Unemployment_in_India.csv")
df.columns = [c.strip() for c in df.columns]

print("Initial shape:", df.shape)
print(df.head())
print("\nMissing values:\n", df.isnull().sum())
print("\nDuplicate rows:", df.duplicated().sum())

# ---------------------------------------------------------
# 2. Data Cleaning
# ---------------------------------------------------------
df = df.drop_duplicates()
df = df.dropna(subset=[RATE_COL])
df[LPR_COL] = df[LPR_COL].fillna(df[LPR_COL].median())

df["Date"] = pd.to_datetime(df["Date"], format="%d-%m-%Y")
df["Month"] = df["Date"].dt.to_period("M").astype(str)
df["Year"] = df["Date"].dt.year
df["Month_Name"] = df["Date"].dt.strftime("%b")

print("\nCleaned shape:", df.shape)

# ---------------------------------------------------------
# 3. Overall statistics
# ---------------------------------------------------------
print("\nOverall summary statistics:")
print(df[RATE_COL].describe())

# ---------------------------------------------------------
# 4. National unemployment trend over time
# ---------------------------------------------------------
monthly_trend = df.groupby("Month")[RATE_COL].mean().reset_index()
monthly_trend["Month"] = pd.to_datetime(monthly_trend["Month"])
monthly_trend = monthly_trend.sort_values("Month")

plt.figure(figsize=(10, 5))
plt.plot(monthly_trend["Month"], monthly_trend[RATE_COL], marker="o", color="#C44E52")
plt.axvspan(pd.Timestamp("2020-03-01"), pd.Timestamp("2020-05-31"),
            color="grey", alpha=0.2, label="COVID-19 Lockdown Period")
plt.title("National Average Unemployment Rate Over Time")
plt.xlabel("Month")
plt.ylabel("Unemployment Rate (%)")
plt.xticks(rotation=45)
plt.legend()
plt.savefig("visuals/01_national_trend.png", dpi=150)
plt.close()

# ---------------------------------------------------------
# 5. Rural vs Urban comparison
# ---------------------------------------------------------
area_trend = df.groupby(["Month", "Area"])[RATE_COL].mean().reset_index()
area_trend["Month"] = pd.to_datetime(area_trend["Month"])
area_trend = area_trend.sort_values("Month")

plt.figure(figsize=(10, 5))
for area, grp in area_trend.groupby("Area"):
    plt.plot(grp["Month"], grp[RATE_COL], marker="o", label=area)
plt.axvspan(pd.Timestamp("2020-03-01"), pd.Timestamp("2020-05-31"), color="grey", alpha=0.2)
plt.title("Rural vs Urban Unemployment Rate Over Time")
plt.xlabel("Month")
plt.ylabel("Unemployment Rate (%)")
plt.xticks(rotation=45)
plt.legend()
plt.savefig("visuals/02_rural_vs_urban.png", dpi=150)
plt.close()

rural_avg = df[df["Area"] == "Rural"][RATE_COL].mean()
urban_avg = df[df["Area"] == "Urban"][RATE_COL].mean()
print(f"\nAverage Rural Unemployment Rate: {rural_avg:.2f}%")
print(f"Average Urban Unemployment Rate: {urban_avg:.2f}%")

# ---------------------------------------------------------
# 6. Region-wise (state-wise) analysis
# ---------------------------------------------------------
state_avg = df.groupby("Region")[RATE_COL].mean().sort_values(ascending=False)

plt.figure(figsize=(8, 9))
sns.barplot(x=state_avg.values, y=state_avg.index, hue=state_avg.index, palette="Reds_r", legend=False)
plt.title("Average Unemployment Rate by State/UT")
plt.xlabel("Average Unemployment Rate (%)")
plt.savefig("visuals/03_state_wise.png", dpi=150)
plt.close()

print("\nTop 5 states by average unemployment rate:")
print(state_avg.head())
print("\nBottom 5 states by average unemployment rate:")
print(state_avg.tail())

# ---------------------------------------------------------
# 7. COVID-19 impact: Pre-COVID vs COVID period
# ---------------------------------------------------------
pre_covid = df[df["Date"] < "2020-03-01"]
covid_period = df[(df["Date"] >= "2020-03-01") & (df["Date"] <= "2020-05-31")]

pre_covid_avg = pre_covid[RATE_COL].mean()
covid_avg = covid_period[RATE_COL].mean()
pct_increase = ((covid_avg - pre_covid_avg) / pre_covid_avg) * 100

print(f"\nPre-COVID average unemployment rate: {pre_covid_avg:.2f}%")
print(f"COVID-period (Mar-May 2020) average unemployment rate: {covid_avg:.2f}%")
print(f"Percentage increase: {pct_increase:.1f}%")

plt.figure(figsize=(5, 5))
plt.bar(["Pre-COVID", "COVID Period\n(Mar-May 2020)"], [pre_covid_avg, covid_avg],
        color=["#4C72B0", "#C44E52"])
plt.ylabel("Average Unemployment Rate (%)")
plt.title("Pre-COVID vs COVID-19 Period Unemployment")
plt.savefig("visuals/04_precovid_vs_covid.png", dpi=150)
plt.close()

# States hit hardest during COVID
covid_state_avg = covid_period.groupby("Region")[RATE_COL].mean().sort_values(ascending=False).head(10)
plt.figure(figsize=(8, 6))
sns.barplot(x=covid_state_avg.values, y=covid_state_avg.index, hue=covid_state_avg.index, palette="Oranges_r", legend=False)
plt.title("Top 10 Hardest-Hit States During COVID-19 (Mar-May 2020)")
plt.xlabel("Average Unemployment Rate (%)")
plt.savefig("visuals/05_covid_hardest_hit_states.png", dpi=150)
plt.close()

# ---------------------------------------------------------
# 8. Labour participation vs unemployment correlation
# ---------------------------------------------------------
corr = df[[RATE_COL, EMP_COL, LPR_COL]].corr()
plt.figure(figsize=(5, 4))
sns.heatmap(corr, annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Correlation: Unemployment, Employment & Labour Participation")
plt.savefig("visuals/06_correlation_heatmap.png", dpi=150)
plt.close()

# ---------------------------------------------------------
# 9. Seasonal / monthly pattern
# ---------------------------------------------------------
monthly_pattern = df.groupby("Month_Name")[RATE_COL].mean()
month_order = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
monthly_pattern = monthly_pattern.reindex([m for m in month_order if m in monthly_pattern.index])

plt.figure(figsize=(9, 5))
sns.barplot(x=monthly_pattern.index, y=monthly_pattern.values, hue=monthly_pattern.index, palette="viridis", legend=False)
plt.title("Average Unemployment Rate by Calendar Month (Seasonal Pattern)")
plt.xlabel("Month")
plt.ylabel("Average Unemployment Rate (%)")
plt.savefig("visuals/07_seasonal_pattern.png", dpi=150)
plt.close()

print("\nAll visuals saved to the 'visuals/' folder.")
print("Done!")
